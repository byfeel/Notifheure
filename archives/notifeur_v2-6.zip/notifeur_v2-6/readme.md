A copier dans un meme repertoire
